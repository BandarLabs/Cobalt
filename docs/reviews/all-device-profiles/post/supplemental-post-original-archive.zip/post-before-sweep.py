import os,json,concurrent.futures,subprocess,hashlib
from pathlib import Path
out=Path('/workspace/post-before');out.mkdir(exist_ok=True)
profiles='clara-bw-391 clara-bw-395 clara-hd-376 clara-colour-393 elipsa-2e-389 libra-2-388 libra-colour-390 libra-colour-390-4.46.23836 libra-h2o-384'.split()
def check(item):
 profile,scale=item;folder=out/profile/scale;folder.mkdir(parents=True,exist_ok=True)
 with (folder/'run.log').open('w') as log:
  code=subprocess.run(['python3','/workspace/post-baseline-adapter.py','--profile',profile,'--scale',scale,'--output',str(folder)],stdout=log,stderr=log).returncode
 row=dict(profile=profile,scale=scale,status='pass' if code==0 else 'fail',source='218b5172262767be2fd25265d2b35f7f9337b8c6');print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(check,[(p,s) for p in profiles for s in ['default','170']]))
(out/'results.json').write_text(json.dumps(rows,indent=2))
(out/'adapter-provenance.json').write_text(json.dumps(dict(adapter_sha256=hashlib.sha256(Path('/workspace/post-baseline-adapter.py').read_bytes()).hexdigest(),source='218b5172262767be2fd25265d2b35f7f9337b8c6',hardware_tested=False,adapter='Only the TLS fixture and page-independent route were adapted; original production source is unchanged.'),indent=2))
